void setup() {
  pinMode(7, INPUT_PULLUP);  // Button pin as input with pull-up
  pinMode(13, OUTPUT);       // LED pin as output
}

void loop() {
  int buttonState = digitalRead(7);  // Read button

  if (buttonState == LOW) {          // Button pressed (LOW because of pull-up)
    digitalWrite(13, HIGH);          // LED ON
  } else {
    digitalWrite(13, LOW);           // LED OFF
  }
}
